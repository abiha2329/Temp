from flask import session, render_template, redirect, url_for, flash, request
from . import main
from .. import db
from ..models import User, Recipe #these are data tables from model file
from .forms import *
from flask_login import login_required, current_user, login_user, logout_user



@main.route("/login", methods = ["GET", "POST"]) #/login

def login():
    form = LoginForm()

    if (form.validate_on_submit()):
        user = User.query.filter_by(username = form.username.data).first()
        if user is not None and user.verify_password(form.password.data):
            login_user(user, form.remember_me.data)
            next = request.args.get("next")
            if next is None or not next.startswith("/"):
                return redirect(url_for("main.home"))
        flash("Invalid username or password")
    return render_template("login.html", form=form)


@main.route("/")

def home():
    return render_template("home.html")

@main.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("main.home")) 

    

@main.route("/register", methods = ["GET", "POST"])
def register():
    form = UserForm()
    
    if(form.validate_on_submit()):
        username = form.username.data
        fname = form.fname.data
        pw = form.password.data
        created = registerUser(username, pw, fname)

        #Add Default cookies recipe for new users

        user = User.query.filter_by(username=username).first()
        id = user.id


        if (created == True):

            addRecipe(id, "Chocolate Chip Cookies", "30 Minutes", "Eggs, Butter, Sugar, Flour, Baking Soda, Chocolate Chips, Vanilla Extract", "1. Preheat Oven to 375 degrees. \n 2. In a large bowl, cream together the butter and sugar. \n 3. Beat in the vanilla and eggs one at a time. \n 4. Combine the flour, baking soda, salt, and sugar. \n 5. Finally, mix in the chocolate chips. Drop onto cookie sheets. \n 6. Bake for 8 to 10 minutes in the preheated oven. \n 7. Remove from baking sheet to cool on wire racks. ")
            return redirect(url_for('main.login'))
    
    return render_template("register.html", form = form)


def registerUser(username, password, fname):
    u = User.query.filter_by(username=username).first()
    if(u == None):
        user = User(username = username, password = password, firstname = fname)
        db.session.add(user)
        db.session.commit()
        return True
    else:
        flash("User already exists")
        return False


@main.route("/add", methods = ["GET", "POST"])
@login_required

def add():
    form = RecipeForm()
    if(form.validate_on_submit()):
        name = form.name.data
        time = form.time.data
        ingredients = form.ingredients.data
        steps = form.steps.data

        addRecipe(current_user.get_id(), name, time, ingredients, steps)

        return redirect(url_for("main.recipes"))

    return render_template("add.html", form = form)


def addRecipe(user_id, name, time, ingredients, steps):
    recipe = Recipe(user_id= user_id, name = name, time = time, ingredients = ingredients, steps = steps)
    db.session.add(recipe)
    db.session.commit()
    return True
        

@main.route("/recipes", methods = ["GET", "POST"])
@login_required

def recipes():

    recipes = Recipe.query.filter_by(user_id = current_user.get_id())

    return render_template("recipes.html", recipes = recipes)


@main.route('/delete', methods=['POST'])

def delete():
    num = request.form['entry_id']
    num = int(num)
    row = Recipe.query.filter_by(id = num).first()
    db.session.delete(row)
    db.session.commit()
    return redirect(url_for('main.recipes'))







