from flask import Flask, request, session, render_template, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from flask_login import login_required, current_user, login_user, logout_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, IntegerField, BooleanField
from wtforms.validators import DataRequired, Length
from config import config
import os
import sys
import click
from app import create_app
from app import db
from app import login_manager

# app stuff - now in init file

#login_manager = LoginManager()
#login_manager.login_view = "login"
#db = SQLAlchemy()

#def create_app(config_name):
    #app = Flask(__name__)
    #app.config.from_object(config[config_name])
    #config[config_name].init_app(app)
    #db.init_app(app)
    #login_manager.init_app(app)
    #return app

COV = None
if os.environ.get("FLASK_COVERAGE"):
    import coverage
    COV = coverage.coverage(branch=True, include="app/*")
    COV.start()

app = create_app(os.getenv("FLASK_CONFIG") or "default")

@app.cli.command()
@click.option("--coverage/--no-coverage", default=False, help="Run tests under code coverage.")
def test(coverage):
    '''run the unit tests'''
    if coverage and not os.environ.get("FLASK_COVERAGE"):
        os.environ["FLASK_COVERAGE"] = "1"
        os.execvp(sys.executable, [sys.executable] + sys.argv)
    
    import unittest
    tests = unittest.TestLoader().discover("tests")
    unittest.TextTestRunner(verbosity=2).run(tests)
    
    if COV:
        COV.stop()
        COV.save()
        print("Coverage Summary:")
        COV.report()
        basedir = os.path.abspath(os.path.dirname(__file__))
        covdir = os.path.join(basedir, "tmp/coverage")
        COV.html_report(directory=covdir)
        print("HTML version: file://%s/index.html" % covdir)
        COV.erase()

#app = create_app(os.getenv("FLASK_CONFIG") or "default")

#copy and paste 