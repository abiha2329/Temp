from flask import Flask, request, session, render_template, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager #
from flask_login import login_required, current_user, login_user, logout_user #
from config import config 



login_manager = LoginManager()
login_manager.login_view = "main.login"

db = SQLAlchemy()




def create_app(config_name):
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    config[config_name].init_app(app)
    
    db.init_app(app)

   
    
    login_manager.init_app(app)
    from .models import User# import databases from models change this for every copy and paste you do
    with app.app_context():
        db.create_all()
    
    from .main import main as main_blueprint
    app.register_blueprint(main_blueprint)
    
    return app
