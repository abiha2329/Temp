
import unittest
from flask import current_app
from app import create_app, db
import re
from app.models import Recipe


# test class

class TestCase(unittest.TestCase):

   # 1) builds and dismantles test cases when done so no effect on program afterwards

    def setUp(self):                                
        self.app = create_app("testing")
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.create_all()
        self.client = self.app.test_client(use_cookies=True)


    def tearDown(self):
        db.session.remove()
        db.drop_all() 
        self.app_context.pop()

    # 2) some basic tests 


    #check if app exists

    def test_app_exists(self):                      
        self.assertFalse(current_app is None) # assertfalse means "make sure its false"

    # check if app is testing

    def test_app_is_testing(self):
        self.assertTrue(current_app.config["TESTING"])

    # 3) Test if pages all load


    # tests if home page loads

    def test_home(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)


      # tests if recipes page loads

    def test_recipes(self):

        import app.main.views

        app.main.views.registerUser("Henry24", "123", "Henry") #mayhaps this is the one we need a new database for

        response = self.client.post("/login", data= {
            "user_id" : 1,
            "username" : "Henry24",
            "password" : "123",
            "remember_me" : True
        })

        recipe = Recipe(id=2, user_id = 1, name = "cookie", time="30 mins", ingredients = "dough", steps="1.bake")
        db.session.add(recipe)
        db.session.commit()

        response = self.client.get("/recipes")
        self.assertEqual(response.status_code, 200)

     # tests if add page loads 

    def test_add(self):
        response = self.client.get("/add")
        self.assertEqual(response.status_code, 302)


    # 4) Test logins


    # tests if you can add user to database

    def test_add_user(self):
        response = self.client.get("/register")
        self.assertEqual(response.status_code, 200)


        response = self.client.post("/register", data={
            "username" : "Ben",
            "fname" : "benn",
            "password" : "123"
        })
    
        self.assertEqual(response.status_code, 302)

     # test if you can add recipe from database

    def test_add_recipe(self):

        import app.main.views


        app.main.views.registerUser("Henry24", "123", "Henry") #mayhaps this is the one we need a new database for

        response = self.client.post("/login", data= {
            "username" : "Henry24",
            "password" : "123",
            "remember_me" : True
        })

       
        response = self.client.post("/add", data={
            "name" : "cookie",
            "time" : "30 mins",
            "ingredients": "celery",
            "steps": "wash it"
        })

        app.main.views.addRecipe(24, "Henry24", "hi", "henry", "123") 
    
        self.assertEqual(response.status_code, 302)


    # test if you can delete recipe from database

    def test_delete_recipe(self):
    
        recipe = Recipe(id=2, user_id = 4, name = "cookie", time="30 mins", ingredients = "dough", steps="1.bake")
        db.session.add(recipe)
        db.session.commit()

        # delete
        response = self.client.post('/delete', data={'entry_id': recipe.id}, follow_redirects=True)

        # Check that it was deleted
        assert Recipe.query.get(recipe.id) is None
        assert response.status_code == 200





    # tests if it stops someone from registering if they already did

    def test_user_already_registered(self):

        import app.main.views
        app.main.views.registerUser("Henry24", "Henry", "123") 

        response = self.client.post("/register", data={
            "username" : "Henry24",
            "fname" : "Henry",
            "password" : "123"

        })

        
      
    # tests if login works

    def test_login(self):

        import app.main.views
        app.main.views.registerUser("Henry24", "123", "Henry") #mayhaps this is the one we need a new database for

        response = self.client.post("/login", data= {
            "username" : "Henry24",
            "password" : "123",
            "remember_me" : True
        })

        self.assertEqual(response.status_code, 302)



    # tests to make sure wrong credentials cannot login 

    def test_login_incorrect(self):
        import app.main.views
        app.main.views.registerUser("marvelfan122", "thanos1/2", "thanos")
        response = self.client.post("/login", data={
            "username" : "marvelfan122",
            "password" : "idk",
            "remember_me" : True
        })

        self.assertEqual(response.status_code, 200)
        #self.assertTrue("Invalid username or password" in response.get_data(as_text=True))

 


    # tests if logout works

    def test_logout(self):

        import app.main.views
        app.main.views.registerUser("Henry24", "123", "henry") #mayhaps this is the one we need a new database for

        response = self.client.post("/login", data= {
            "username" : "Henry24",
            "password" : "123",
            "remember_me" : True
        })

        response = self.client.get("/logout")

        self.assertEqual(response.status_code, 302)
    
    # checks if login required works
    
    def test_protected(self):
        response = self.client.get("/recipes", follow_redirects=True)


    # test error file template

    def test_404_error_handler(self):
        response = self.client.get('/none')
        self.assertEqual(response.status_code, 404)

        
       

        



   