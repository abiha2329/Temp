TO RUN: type export FLASK_APP=flasky.py

Name of Website: Baking Recipes Book

Purpose: My project is a website called "Baking Recipes Book" where users can store their baking recipes they have. The purpose of this website is to store recipes and help with your recipe organization.

Navigation: Putting in the flask development server link takes you to the Home Page. You can press the login button to go to the login page, or press the register button to go to the registration page. From there, the navigation bar has links to other pages including: "My Recipes" and a "Add a Recipe" Page. The login page also has a link to register to make an account. The "My Recipes" page and "add" page require login. 

Important URLS:
- /: Takes you to home page
- /add: Lets you add a recipe
- /recipes: Shows you your recipes
- /delete: button lets you delete a recipe. 
- /login: lets you login
- /register: lets you register
- /logout: lets you logout

Database Table Configurations:

Users Table:
- tablename : "users"
- id: Integer, Primary Key
- username: String, unique, index
- password_hash: String
- firstname: String, index

Recipe Table:
- tablename : "recipes"
- id: Integer, Primary Key
- user_id: Integer, index
- name = String, index
- time = String
- ingredients = Text
- steps = Text

ADDITIONAL REQUIREMENTS IMPLEMENTED:

1. User Authentication - this is in login, register and logout pages. Users table is used.
2. Additional database interactions - Another table is Recipes table, can insert using "add" page and delete with delete button on "my recipes" page. 
3. Testing - tests file has unit testing that covers 91% of application. 
