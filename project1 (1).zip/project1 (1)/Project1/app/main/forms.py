from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, IntegerField, BooleanField
from wtforms import TextAreaField
from wtforms.validators import DataRequired, Length


# Forms

class UserForm(FlaskForm):
    username = StringField("Username: ", validators = [DataRequired()])
    password = PasswordField("Password: ", validators = [DataRequired()])
    fname = StringField("First name: ", validators = [DataRequired()])
    submit = SubmitField("Register")

class LoginForm(FlaskForm):
    username = StringField("Username: ", validators = [DataRequired()])
    password = PasswordField("Password: ", validators = [DataRequired()])
    remember_me = BooleanField("Keep me logged in")
    submit = SubmitField("Login")

class BlogForm(FlaskForm):
    title = StringField("Title: ", validators = [DataRequired()])
    subject = StringField("Subject: ", validators = [DataRequired()])
    content = TextAreaField('Explanation:', validators=[DataRequired()])
    submit = SubmitField("Submit")

