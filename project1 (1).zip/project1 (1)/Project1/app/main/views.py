from flask import session, render_template, redirect, url_for, flash, request
from . import main
from .. import db
from ..models import User, Blog
from .forms import *
from flask_login import login_required, current_user, login_user, logout_user




@main.route("/", methods = ["GET", "POST"]) #/login

def login():
    form = LoginForm()

    if (form.validate_on_submit()):
        user = User.query.filter_by(username = form.username.data).first()
        if user is not None and user.verify_password(form.password.data):
            login_user(user, form.remember_me.data)
            next = request.args.get("next")
            if next is None or not next.startswith("/"):
                next = url_for("main.mainpage")
            return redirect(next)
        flash("Invalid username or password")
    return render_template("login.html", form=form)


@main.route("/mainpage")
@login_required

def mainpage():

    blogs = Blog.query.order_by(Blog.id.desc()).all()

    return render_template("mainpage.html", blogs = blogs)


@main.route("/createblog", methods = ["GET", "POST"])
@login_required

def createblog():

    form = BlogForm()

    if (form.validate_on_submit()):

        title = form.title.data
        subject = form.subject.data
        content = form.content.data
        username = current_user.username

        CreateBlog(title,subject, content, username)


        return redirect(url_for("main.mainpage"))


    return render_template("createblog.html", form = form)


def CreateBlog(title, subject, content, username):

    # get author

    user = User.query.filter_by(username = username).first()

    author_id = user.id

    blog = Blog(title = title, subject = subject, content = content, author = username, author_id = author_id)

    db.session.add(blog)
    db.session.commit()



@main.route("/myblogs")
@login_required
def myblogs():

    user = current_user.id # access user id

    blogs = Blog.query.filter_by(author_id=user) 


    return render_template("myblogs.html", blogs = blogs)
    
    
@main.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.")
    return redirect(url_for("main.login")) #index

    

@main.route("/register", methods = ["GET", "POST"])
def register():
    form = UserForm()
    
    if(form.validate_on_submit()):
        username = form.username.data
        fname = form.fname.data
        pw = form.password.data
        created = registerUser(username, pw, fname)
        
        return redirect(url_for('main.login'))
    
    return render_template("register.html", form = form)


def registerUser(username, password, fname):
    u = User.query.filter_by(username=username).first()
    if(u == None):
        user = User(username = username, password = password, firstname = fname)
        db.session.add(user)
        db.session.commit()
        return True
    else:
        return False

















