TO RUN: type export FLASK_APP="flasky.py"

Name of Website: Opinion Express

Purpose: My project is a website called "Opinion Express" where users can post funny short blogs of unpopular opinions they have. The purpose of this website is Entertainment. 

Navigation: Putting in the flask development server link takes you to the login page which directs you to the main page - "Opinions". From there, the navigation bar has links to other pages including: "Your Posts" and a "Add an Opinion" Page. The login page also has a link to register to make an account. 

Important URLS: 
- /createblog: Lets you post a blog 
- /myblogs: Shows you blogs you created
- /: Default - takes you to login page
- /mainpage: Takes you to page full of blog posts
-/logout: Logs you out
-/register: Lets you create an account.

Database Table Configurations:

Users Table:
- tablename : "users"
- id: Integer, Primary Key
- username: String, unique, index
- password_hash: String
- firstname: String, index
- blogs: relationship("Blog")

Blog Table:
- tablename : "blogs"
- id: Integer, primary key
- title: String, index
- Subject: String, index
- content: Text
- author: String, index
- author_id: Integer, FOREIGN KEY to users_id table



Requirements are in requirements.txt file